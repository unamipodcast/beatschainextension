// Minimal Test App for Dual-Chain Testing
class TestApp {
    constructor() {
        this.currentSection = 'upload-section';
        this.beatFile = null;
        this.thirdweb = null;
    }

    async initialize() {
        console.log('🧪 BeatsChain Test App Starting...');
        
        this.setupEventListeners();
        
        try {
            this.thirdweb = new ThirdwebManager();
            console.log('✅ ThirdwebManager initialized');
        } catch (error) {
            console.error('❌ ThirdwebManager failed:', error);
        }
    }

    setupEventListeners() {
        // File upload
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('audio-file');
        
        uploadArea?.addEventListener('click', () => fileInput.click());
        fileInput?.addEventListener('change', this.handleFileSelect.bind(this));
        
        // Proceed to minting
        document.getElementById('proceed-to-minting')?.addEventListener('click', () => {
            this.showSection('minting-section');
        });
        
        // Blockchain selector
        document.querySelectorAll('input[name="blockchain"]').forEach(radio => {
            radio.addEventListener('change', this.handleBlockchainChange.bind(this));
        });
        
        // Mint button
        document.getElementById('mint-nft')?.addEventListener('click', this.testMint.bind(this));
        
        // View transaction
        document.getElementById('view-transaction')?.addEventListener('click', this.viewTransaction.bind(this));
        
        // Test another
        document.getElementById('test-another')?.addEventListener('click', this.resetTest.bind(this));
    }

    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.beatFile = file;
            console.log('📁 File selected:', file.name);
            
            // Show preview
            const preview = document.getElementById('audio-preview');
            preview.innerHTML = `<p>✅ ${file.name} (${(file.size/1024/1024).toFixed(2)}MB)</p>`;
            
            // Show form
            document.getElementById('artist-form').style.display = 'block';
        }
    }

    handleBlockchainChange(event) {
        const blockchain = event.target.value;
        console.log(`🔄 Blockchain changed to: ${blockchain}`);
        
        if (this.thirdweb) {
            this.thirdweb.setNetwork(blockchain);
        }
        
        // Update cost display
        const costElement = document.getElementById('estimated-cost');
        if (blockchain === 'solana') {
            costElement.textContent = '~$0.001';
            costElement.style.color = '#28a745';
        } else {
            costElement.textContent = '~$0.01';
            costElement.style.color = '#007bff';
        }
    }

    async testMint() {
        const mintBtn = document.getElementById('mint-nft');
        const statusDiv = document.getElementById('mint-status');
        
        if (!this.beatFile) {
            alert('Please upload a test file first');
            return;
        }
        
        mintBtn.disabled = true;
        statusDiv.textContent = 'Testing mint...';
        statusDiv.className = 'mint-status pending';
        
        try {
            const artistName = document.getElementById('artist-name').value || 'Test Artist';
            const beatTitle = document.getElementById('beat-title').value || 'Test Beat';
            
            console.log(`🧪 Testing mint: ${beatTitle} by ${artistName}`);
            
            // Simulate IPFS upload
            statusDiv.textContent = 'Uploading to IPFS...';
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const mockMetadataUri = 'ipfs://QmTestHash123456789';
            
            // Test minting
            statusDiv.textContent = 'Minting on blockchain...';
            
            if (!this.thirdweb) {
                throw new Error('ThirdwebManager not initialized');
            }
            
            // Initialize with test key
            await this.thirdweb.initialize('test_private_key_for_testing');
            
            const result = await this.thirdweb.mintNFT('0xTestAddress123', mockMetadataUri);
            
            console.log('✅ Test mint result:', result);
            
            this.showMintSuccess(result);
            
        } catch (error) {
            console.error('❌ Test mint failed:', error);
            statusDiv.className = 'mint-status error';
            statusDiv.textContent = `Test failed: ${error.message}`;
            mintBtn.disabled = false;
        }
    }

    showMintSuccess(result) {
        document.getElementById('tx-hash').textContent = result.transactionHash;
        this.currentTxHash = result.transactionHash;
        this.showSection('success-section');
    }

    viewTransaction() {
        if (this.currentTxHash && this.thirdweb) {
            const url = this.thirdweb.getExplorerUrl(this.currentTxHash);
            window.open(url, '_blank');
        }
    }

    resetTest() {
        this.beatFile = null;
        this.currentTxHash = null;
        document.getElementById('audio-file').value = '';
        document.getElementById('artist-name').value = '';
        document.getElementById('beat-title').value = '';
        document.getElementById('audio-preview').innerHTML = '';
        document.getElementById('artist-form').style.display = 'none';
        document.getElementById('mint-status').textContent = '';
        this.showSection('upload-section');
    }

    showSection(sectionId) {
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionId)?.classList.add('active');
        this.currentSection = sectionId;
    }
}

// Initialize test app
const testApp = new TestApp();
testApp.initialize();

// Export for console testing
window.testApp = testApp;