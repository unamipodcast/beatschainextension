# BeatsChain Test Package v2.1.2

## 🧪 Dual-Chain Testing

This is a lean test package for testing BeatsChain's dual-chain NFT minting functionality.

### Features Included:
- ✅ Ethereum testnet minting
- ✅ Solana devnet minting  
- ✅ Blockchain selector UI
- ✅ Real-time cost comparison
- ✅ Transaction verification

### Testing Instructions:

1. **Load Extension:**
   - Open Chrome
   - Go to chrome://extensions/
   - Enable Developer mode
   - Click "Load unpacked"
   - Select this folder

2. **Test Dual-Chain Minting:**
   - Upload a small audio file
   - Fill in test artist info
   - Select blockchain (Ethereum/Solana)
   - Click "Test Mint NFT"
   - Verify transaction creation

3. **Verify Results:**
   - Check console for logs
   - Verify cost differences
   - Test blockchain switching
   - Confirm transaction hashes

### Expected Results:
- Ethereum: ~$0.01 cost, 0x... hash format
- Solana: ~$0.001 cost, Base58 signature format
- Both: Successful transaction creation

### File Size: ~2MB (vs 15MB+ full version)
### Load Time: <1 second
### Test Coverage: Core dual-chain functionality

**Status: Ready for testing**